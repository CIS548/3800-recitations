#ifndef PROC_AND_PIPE_H
#define PROC_AND_PIPE_H

void proc_and_pipe_example();

#endif
