#ifndef SIGNALS_H
#define SIGNALS_H

void signals_example();

#endif
