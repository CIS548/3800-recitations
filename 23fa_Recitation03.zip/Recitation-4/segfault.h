#ifndef SEGFAULT_H
#define SEGFAULT_H

void segfault_example();

#endif
